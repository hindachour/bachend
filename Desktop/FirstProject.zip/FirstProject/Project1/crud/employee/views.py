from django.shortcuts import render,redirect
from .models import Employee
from .forms import EmployeeForm

def emp(request):

    if request.method=="POST":
        eid=request.POST.get('eid')  #get(nom de key)
        ename=request.POST.get('ename')
        email=request.POST.get('email')
        econtact=request.POST.get('econtact')
        data=EmployeeForm(request.POST)  #econtact(esm colonne fel base)=econtact(valeur)
        data.save()
        return redirect("/show")
    else:

        return render(request,'index.html',{'ef':EmployeeForm()})


def show(request):
   employees=Employee.objects.all()
   return render(request, "show.html", {'emplo':employees}) 

def edit(request, id):
    employee=Employee.objects.get(id=id)
    return render(request,'edit.html',{'employee':employee})

def update(request, id):
   employee=Employee.objects.get(id=id)
   form=EmployeeForm(request.POST,instance=employee)
   if form.is_valid():
      form.save()
      return redirect("/show")
   return render(request,'edit.html',{'employee':employee})

def destroy(request, id):
    employee = Employee.objects.get(id=id)
    employee.delete()
    return redirect("/show") 
  
