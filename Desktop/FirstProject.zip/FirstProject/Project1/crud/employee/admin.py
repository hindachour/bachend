from django.contrib import admin
from .models import Employee  # Utilisez 'Employee' avec une majuscule

# Enregistrez le modèle dans l'interface admin
admin.site.register(Employee)

