<?php
include_once("Client.php");
$cl = new Client();
$idClient = $_POST['idClient'];
$cl->delete($idClient);
header("Location: listClient.php");
?>

