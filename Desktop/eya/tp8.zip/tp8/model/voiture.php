<?php
require_once 'Modele.php';


    class Voiture extends Modele {
        private $idVoiture;
        private $numSerie;
        private $marque;
        private $carburant;
        private $prixLocation;
    
        public function __construct($idVoiture, $numSerie, $marque, $carburant, $prixLocation) {
            $this->idVoiture = $idVoiture;
            $this->numSerie = $numSerie;
            $this->marque = $marque;
            $this->carburant = $carburant;
            $this->prixLocation = $prixLocation;
            parent::__construct();
        }
    
        // Getters pour les propriétés privées
        public function getIdVoiture() {
            return $this->idVoiture;
        }
    
        public function getNumSerie() {
            return $this->numSerie;
        }
    
        public function getMarque() {
            return $this->marque;
        }
    
        public function getCarburant() {
            return $this->carburant;
        }
    
        public function getPrixLocation() {
            return $this->prixLocation;
        }
        public static function rechercherParCarburant($carburant) {
          
            $pdo = (new self(null, null, null, null, null))->pdo;
    
            $query = "SELECT * FROM voiture WHERE carburant = ?";
            $res = $pdo->prepare($query);
            $res->execute([$carburant]); 
    
            $voitures = [];
    
           
            while ($row = $res->fetch()) {
                $voitures[] = new Voiture(
                    $row[0], 
                    $row[1],
                    $row[2], 
                    $row[3], 
                    $row[4]  
                );
            }
    
            return $voitures;
        }
    }
    

?>
