<?php
require_once 'Voiture.php'; // Inclure la classe Voiture



    if (count($voitures) > 0) {
        echo "<h2>Résultats pour le carburant : $carburant</h2>";
        echo "<table border='1'>
                <tr>
                    <th>ID</th>
                    <th>Numéro de Série</th>
                    <th>Marque</th>
                    <th>Carburant</th>
                    <th>Prix de Location</th>
                </tr>";
        foreach ($voitures as $voiture) {
            echo foreach ($voitures as $voiture) {
                echo "<tr>
                        <td>{$voiture->getIdVoiture()}</td>
                        <td>{$voiture->getNumSerie()}</td>
                        <td>{$voiture->getMarque()}</td>
                        <td>{$voiture->getCarburant()}</td>
                        <td>{$voiture->getPrixLocation()}</td>
                    </tr>";
            }
            
        }
        echo "</table>";
    } else {
        echo "<p>Aucune voiture trouvée pour le carburant : $carburant.</p>";
    }
 
?>

